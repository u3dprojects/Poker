package server;


import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

public class NettyMessageEncoder extends MessageToByteEncoder<NettyMessage>{

	@Override
	protected void encode(ChannelHandlerContext arg0, NettyMessage msg, ByteBuf out) throws Exception {
		int lens = msg.getBody().length + 4;
		out.writeIntLE(lens);
		out.writeShortLE(msg.getCommandId());
		out.writeShortLE(msg.getStatus());
		out.writeBytes(msg.getBody());
		
		byte[] bv = new byte[20];
		InputStream inStream = new ByteArrayInputStream(bv);
		inStream.read();
		
	}
}
