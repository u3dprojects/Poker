package server;


import java.util.List;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

public class NettyMessageDecoder extends ByteToMessageDecoder {

	long begTime = 0;
	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
		if (in.readableBytes() < NettyMessage.HEADER_LENGTH) {
			return;
		}
		long cur = System.currentTimeMillis();
		if(begTime > 0){
			System.err.println("=diff ms =" + (cur - begTime));
		}
		begTime = cur;
		
		NettyMessage msg = new NettyMessage();
		msg.setLength(in.readIntLE());
		msg.setCommandId(in.readShortLE());
		msg.setStatus(in.readShortLE());
		int bodyLength = msg.getLength() - NettyMessage.HEADER_LENGTH;
		byte[] body = new byte[bodyLength];
		in.readBytes(body);
		msg.setBody(body);
		out.add(msg);
	}
}
