package server;
import java.util.Arrays;

public class NettyMessage {
	/**
	 * 包头长度(4 + 2 + 2)
	 */
	public static final int HEADER_LENGTH = 8;
	public static final int HEADER_LENGTH_BACK = 4;

	/**
	 * 包长度
	 */
	private int length;
	/**
	 * 指令id
	 */
	private short commandId;
	/**
	 * 状态码(0为正常 其他全为Error)
	 */
	private short status;
	/**
	 * 消息体
	 */
	private byte[] body;

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public short getCommandId() {
		return commandId;
	}

	public void setCommandId(short commandId) {
		this.commandId = commandId;
	}

	public short getStatus() {
		return status;
	}

	public void setStatus(short status) {
		this.status = status;
	}

	public byte[] getBody() {
		return body;
	}

	public void setBody(byte[] body) {
		this.body = body;
	}

	public static int getHeaderLength() {
		return HEADER_LENGTH;
	}

	@Override
	public String toString() {
		return "NettyMessage [length=" + length + ", commandId=" + commandId + ", status=" + status + ", body="+ Arrays.toString(body) + "]";
	}
}
