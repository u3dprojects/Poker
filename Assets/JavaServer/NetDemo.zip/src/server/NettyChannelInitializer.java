package server;


import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;

public class NettyChannelInitializer extends ChannelInitializer<SocketChannel> {

	@Override
	protected void initChannel(SocketChannel sc) throws Exception {
		ChannelPipeline p = sc.pipeline();
		p.addLast("decodec", new NettyMessageDecoder());
		p.addLast("encodec", new NettyMessageEncoder());
		p.addLast("heartbeat", new HeartBeatHandler());
		p.addLast("logicHandler", new NettyHandler());
	}

}
