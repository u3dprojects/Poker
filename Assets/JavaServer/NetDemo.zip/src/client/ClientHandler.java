package client;

import java.util.Date;

import com.demo.protobuf.DemoMsg;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import server.NettyMessage;

public class ClientHandler extends ChannelInboundHandlerAdapter {

	@Override
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
		super.channelActive(ctx);

		sendMsg(ctx);

		System.out.println("----> 登录成功 " + new Date());
	}

	private void sendMsg(ChannelHandlerContext ctx) {
		DemoMsg.DemoRequest.Builder builder = DemoMsg.DemoRequest.newBuilder();
		builder.setAccountId("695990439@qq.com");
		builder.setIP("127.0.0.1");
		builder.setServerId(5);
		
		
		NettyMessage msg = new NettyMessage();
		msg.setCommandId((short) 1111);
		msg.setBody(builder.build().toByteArray());
		
		ctx.writeAndFlush(msg);
	}

	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
		super.channelInactive(ctx);
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
		super.channelRead(ctx, msg);
		NettyMessage nettyMsg = (NettyMessage) msg;
		if (nettyMsg.getCommandId() == 1111) {
			System.out.println("DEMO response :" + nettyMsg );
			System.out.println("Demo Budy :" + DemoMsg.DemoResponse.parseFrom(nettyMsg.getBody()));
			sendMsg(ctx);
	}
	}

	@Override
	public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
		// TODO Auto-generated method stub
		super.channelReadComplete(ctx);
	}

	@Override
	public void channelRegistered(ChannelHandlerContext ctx) throws Exception {
		// TODO Auto-generated method stub
		super.channelRegistered(ctx);
	}

	@Override
	public void channelUnregistered(ChannelHandlerContext ctx) throws Exception {
		// TODO Auto-generated method stub
		super.channelUnregistered(ctx);
	}

	@Override
	public void channelWritabilityChanged(ChannelHandlerContext ctx) throws Exception {
		// TODO Auto-generated method stub
		super.channelWritabilityChanged(ctx);
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		// TODO Auto-generated method stub
		super.exceptionCaught(ctx, cause);
	}

	@Override
	public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
		// TODO Auto-generated method stub
		super.userEventTriggered(ctx, evt);
	}

}
