package client;

import io.netty.channel.CombinedChannelDuplexHandler;
import io.netty.handler.codec.ByteToMessageDecoder;
import io.netty.handler.codec.MessageToByteEncoder;
import server.NettyMessage;
import server.NettyMessageDecoder;
import server.NettyMessageEncoder;

/**
 * 自定义加密方式的服务器编码解码处理器
 * @author wk.dai
 */
public class ClientCodec
		extends
		CombinedChannelDuplexHandler<ByteToMessageDecoder, MessageToByteEncoder<NettyMessage>> {

	public ClientCodec() {
		this(new NettyMessageDecoder(), new NettyMessageEncoder());
	}

	public ClientCodec(ByteToMessageDecoder inboundHandler,
			MessageToByteEncoder<NettyMessage> outboundHandler) {
		super(inboundHandler, outboundHandler);
	}
}
