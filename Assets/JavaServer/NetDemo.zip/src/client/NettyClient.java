package client;

import java.util.Date;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;

public class NettyClient {
	public void connect(String host, int port) {
		EventLoopGroup group = new NioEventLoopGroup();
		try {
			Bootstrap b = new Bootstrap();
			b.group(group).channel(NioSocketChannel.class).option(ChannelOption.TCP_NODELAY, true)
					.handler(new ChannelInitializer<SocketChannel>() {
						@Override
						protected void initChannel(SocketChannel ch) throws Exception {
							ch.pipeline().addLast("codec", new ClientCodec());
							ch.pipeline().addLast("handler", new ClientHandler());
						}
					});
			ChannelFuture f = b.connect(host, port).sync();
			System.out.println("--> 链接成功 " + new Date());
			f.channel().closeFuture().sync();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("异常断开 " + new Date());
		} finally {
			System.out.println("正常断开 " + new Date());
		}
	}

	public static void main(String[] args) {
		String host = "127.0.0.1";
		int port = 9999;
		new NettyClient().connect(host, port);
	}
}
