package server;


import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

public class NettyMessageEncoder extends MessageToByteEncoder<NettyMessage>{

	@Override
	protected void encode(ChannelHandlerContext arg0, NettyMessage msg, ByteBuf out) throws Exception {
		out.writeIntLE(msg.getBody().length + NettyMessage.HEADER_LENGTH);
		out.writeShortLE(msg.getCommandId());
		out.writeShortLE(msg.getStatus());
		out.writeBytes(msg.getBody());
	}
}
