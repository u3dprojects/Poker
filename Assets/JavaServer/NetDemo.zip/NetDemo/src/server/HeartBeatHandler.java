package server;
import com.demo.protobuf.DemoMsg;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

/**
 * @author : DengYing
 * @CreateDate : 2017年4月10日 下午2:55:41
 * @Description ：Please describe this document
 */
public class HeartBeatHandler extends ChannelInboundHandlerAdapter {

	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
		NettyMessage nettyMsg = (NettyMessage) msg;
		if (nettyMsg.getCommandId() == 1111) {
				System.out.println("DEMO request :" + nettyMsg );
				System.out.println("Demo Budy :" + DemoMsg.DemoRequest.parseFrom(nettyMsg.getBody()));
				NettyMessage respMsg = buildHeartBeatRespMsg(nettyMsg.getCommandId());
				ctx.writeAndFlush(respMsg);
		}else {
			ctx.fireChannelRead(msg);
		}
	}

	private NettyMessage buildHeartBeatRespMsg(Short commandId) {
		NettyMessage msg = new NettyMessage();
		DemoMsg.DemoResponse.Builder response = DemoMsg.DemoResponse.newBuilder();
		response.setName("SandKing");
		response.setLvl(99);
		msg.setCommandId(commandId);
		msg.setStatus((short) 0);
		msg.setBody(response.build().toByteArray());
		return msg;
	}
}
