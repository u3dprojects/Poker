package server;


import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;

public class NettyServer{
	EventLoopGroup bossGroup;
	EventLoopGroup workerGroup;

	public boolean bind(String host,int prot) {
		bossGroup = new NioEventLoopGroup();
		workerGroup = new NioEventLoopGroup();

		ServerBootstrap bootstrap = new ServerBootstrap();
		bootstrap.group(bossGroup, workerGroup)
		.option(ChannelOption.SO_BACKLOG, 100)
		.channel(NioServerSocketChannel.class)
		.childHandler(new NettyChannelInitializer());
		try {
			ChannelFuture f = bootstrap.bind(host, prot).sync();
			System.out.println("Netty Server start Success! Prot = " + prot);
			f.channel().closeFuture().sync();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}finally {
			bossGroup.shutdownGracefully();
			workerGroup.shutdownGracefully();
		}
		return true;
	}
	
	public static void main(String[] args) {
		new NettyServer().bind("127.0.0.1", 9999);
	}

}
